require.config({
               paths: {
                    CCPayment: 'CCPayment'
               }
               });

